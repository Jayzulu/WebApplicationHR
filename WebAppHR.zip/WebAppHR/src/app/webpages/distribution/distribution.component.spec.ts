import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DistributionComponent } from './distribution.component';

describe('DistributionComponent', () => {
  let component: DistributionComponent;
  let fixture: ComponentFixture<DistributionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DistributionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DistributionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
